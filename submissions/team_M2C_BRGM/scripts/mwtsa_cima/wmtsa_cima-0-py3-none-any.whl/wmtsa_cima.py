
import numpy as np
from scipy.stats import norm, chi2

class dwtArray(np.ndarray):
    """
    class dwtArray(numpy.ndarray)
    
    NAME
       dwtArray -- generic array containing meta data on the transformation
    
    INPUTS
       same as numpy.ndarray
       
       info -- (optional) pass a dictionary of meta data
       
    DESCRIPTION
       An array class that contains meta data.
       This is the basic building block of the package, since it enables to 
       easily pass data with information on the transformations applied to
       the various functions
       
    EXAMPLE
       a = np.arange(10)
       b = a.view(dwtArray)
       b.info = {'metadata':'info'}
       
    WARNINGS
    
    ERRORS  
    
    NOTES
    
    ALGORITHM
    
    REFERENCES
       http://docs.scipy.org/doc/numpy/user/basics.subclassing.html
        
    SEE ALSO
    """
    
    stdinfo = {'Transform': None,
               'Type'     : None,
               'WTF'      : None,
               'N'        : None,
               'NW'       : None,
               'J0'       : None,
               'Boundary' : None,
               'Aligned'  : None,
               'RetainVJ' : None,
               'BCs'      : None
               }
    
    def __new__(cls, input_array, info=stdinfo):
        # Input array is an already formed ndarray instance
        # We first cast to be our class type
        obj = np.asarray(input_array).view(cls)
        # add the new attribute to the created instance
        obj.info = info
        # Finally, we must return the newly created object:
        return obj

    def __array_finalize__(self, obj):
        # see InfoArray.__array_finalize__ for comments
        if obj is None: return
        self.info = getattr(obj, 'info', self.stdinfo)

class wtfilter(object):
    """
    wtfilter -- Class defining the wavelet filter, see __init__
    """
    
    def __init__(self, wtfilter, transform='MODWT'):
        """
         wtfilter -- Define wavelet transform filter coefficients.
        
         NAME
           wtfilter -- Define wavelet transform filter coefficients.
        
         INPUTS
           * wtfname    -- name of wavelet transform filter (string, case-insenstive).
           * transform  -- name of wavelet transform  (string, case-insenstive).
        
         OUTPUTS
           * wtf        -- wavelet tranform filter class (wtf_s).
        
         DESCRIPTION
           wtfilter returns a class with the wavelet (high-pass) and
           scaling (low-pass) filter coefficients, and associated attributes. 
        
           The wtf_s class has attributes:
           * g         -- scaling (low-pass) filter coefficients (vector).
           * h         -- wavelet (high-pass) filter coefficients (vector).
           * L         -- filter length (= number of coefficients) (integer).
           * Name      -- name of wavelet filter (character string).
           * WTFclass  -- class of wavelet filters (character string).
           * Transform -- name of transform (character string).
        
           The MODWT filter coefficients are calculated from the DWT filter 
           coefficients:
        
              ht = h / sqrt(2)
              gt = g / sqrt(2)
        
           The wavelet filter coefficients (h) are calculated from the scaling
           filter coefficients via the QMF function (wmtsa_qmf).
         
         EXAMPLE
            wtf = wtfilter('LA8', 'modwt')
            wtf = wtfilter('haar', 'dwt')
        
         ALGORITHM
        
        
         REFERENCES
           Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
             Time Series Analysis. Cambridge: Cambridge University Press.
        
         SEE ALSO
          wtf_s, wtf_qmf
        """

#TODO: implement other wavelet filters

        if wtfilter.lower()=='la8':
            # **********************************
            # ***  Least asymmetric filters  ***
            # **********************************
            self.Name ='LA8'
            self.g = np.array(\
                        [-0.0757657147893407,-0.0296355276459541, 0.4976186676324578,\
                          0.8037387518052163,  0.2978577956055422,-0.0992195435769354,\
                         -0.0126039672622612,  0.0322231006040713])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 8
            self.SELFClass = 'LeastAsymmetric'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='la10':
            self.Name ='LA10'
            self.g = np.array(\
                             [0.0195388827353869, -0.0211018340249298, -0.1753280899081075,\
                              0.0166021057644243,  0.6339789634569490,  0.7234076904038076,\
                              0.1993975339769955, -0.0391342493025834,  0.0295194909260734,\
                              0.0273330683451645])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 10
            self.WTFClass = 'LeastAsymmetric'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='la12':
            self.Name ='LA12'
            self.g = np.array(\
                              [0.0154041093273377, 0.0034907120843304, -0.1179901111484105,
                              -0.0483117425859981, 0.4910559419276396,  0.7876411410287941,
                               0.3379294217282401,-0.0726375227866000, -0.0210602925126954,
                               0.0447249017707482, 0.0017677118643983, -0.0078007083247650])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 12
            self.WTFClass = 'LeastAsymmetric'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='la14':
            self.Name ='LA14'
            self.g = np.array(\
                              [0.0102681767084968, 0.0040102448717033, -0.1078082377036168,
                              -0.1400472404427030, 0.2886296317509833,  0.7677643170045710,
                               0.5361019170907720, 0.0174412550871099, -0.0495528349370410,
                               0.0678926935015971, 0.0305155131659062, -0.0126363034031526,
                              -0.0010473848889657, 0.0026818145681164])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 14
            self.WTFClass = 'LeastAsymmetric'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='la16':
            self.Name ='LA16'
            self.g = np.array(\
                              [-0.0033824159513594, -0.0005421323316355, 0.0316950878103452,
                                0.0076074873252848, -0.1432942383510542, -0.0612733590679088,
                                0.4813596512592012,  0.7771857516997478,  0.3644418948359564,
                               -0.0519458381078751, -0.0272190299168137,  0.0491371796734768,
                                0.0038087520140601, -0.0149522583367926, -0.0003029205145516,
                                0.0018899503329007])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 16
            self.WTFClass = 'LeastAsymmetric'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='la18':
            self.Name ='LA18'
            self.g = np.array(\
                              [0.0010694900326538, -0.0004731544985879, -0.0102640640276849,
                               0.0088592674935117,  0.0620777893027638, -0.0182337707798257,
                              -0.1915508312964873,  0.0352724880359345,  0.6173384491413523,
                               0.7178970827642257,  0.2387609146074182, -0.0545689584305765,
                               0.0005834627463312,  0.0302248788579895, -0.0115282102079848,
                              -0.0132719677815332,  0.0006197808890549,  0.0014009155255716])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 18
            self.WTFClass = 'LeastAsymmetric'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='la20':
            self.Name ='LA20'
            self.g = np.array(\
                              [0.0007701598091030, 0.0000956326707837, -0.0086412992759401,
                              -0.0014653825833465, 0.0459272392237649,  0.0116098939129724,
                              -0.1594942788575307,-0.0708805358108615,  0.4716906668426588,
                               0.7695100370143388, 0.3838267612253823, -0.0355367403054689,
                              -0.0319900568281631, 0.0499949720791560,  0.0057649120455518,
                              -0.0203549398039460,-0.0008043589345370,  0.0045931735836703,
                               0.0000570360843390,-0.0004593294205481])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 20
            self.WTFClass = 'LeastAsymmetric'
            self.Transform = 'DWT'
        elif wtfilter.lower()in('haar','d2'):
            # **********************************
            # ***  Extremal phase filters    ***
            # **********************************
            self.Name = 'Haar'
            self.g = np.array(\
                              [0.7071067811865475, 0.7071067811865475])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 2
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d4':
            self.Name = 'D4'
            self.g    = np.array(\
                                 [0.4829629131445341, 0.8365163037378077, 0.2241438680420134, -0.1294095225512603])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 4
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d6':
            self.Name = 'D6'
            self.g = np.array(\
                              [0.3326705529500827, 0.8068915093110928, 0.4598775021184915,
                              -0.1350110200102546,-0.0854412738820267, 0.0352262918857096])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 6
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d8':
            self.Name ='D8'
            self.g = np.array(\
                              [0.2303778133074431, 0.7148465705484058, 0.6308807679358788,
                              -0.0279837694166834,-0.1870348117179132, 0.0308413818353661,
                               0.0328830116666778,-0.0105974017850021])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 8
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d10':
            self.Name ='D10'
            self.g = np.array(\
                              [0.1601023979741930, 0.6038292697971898, 0.7243085284377729,
                               0.1384281459013204,-0.2422948870663824,-0.0322448695846381,
                               0.0775714938400459,-0.0062414902127983,-0.0125807519990820,
                               0.0033357252854738])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 10
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d12':
            self.Name ='D12'
            self.g = np.array(\
                              [0.1115407433501094, 0.4946238903984530, 0.7511339080210954,
                               0.3152503517091980,-0.2262646939654399,-0.1297668675672624,
                               0.0975016055873224, 0.0275228655303053,-0.0315820393174862,
                               0.0005538422011614, 0.0047772575109455,-0.0010773010853085])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 12
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d14':
            self.Name ='D14'
            self.g = np.array(\
                              [0.0778520540850081, 0.3965393194819136, 0.7291320908462368,
                               0.4697822874052154,-0.1439060039285293,-0.2240361849938538,
                               0.0713092192668312, 0.0806126091510820,-0.0380299369350125,
                              -0.0165745416306664, 0.0125509985560993, 0.0004295779729214,
                              -0.0018016407040474, 0.0003537137999745])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 14
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d16':
            self.Name ='D16'
            self.g = np.array(\
                              [0.0544158422431049, 0.3128715909143031, 0.6756307362972904,
                               0.5853546836541907,-0.0158291052563816,-0.2840155429615702,
                               0.0004724845739124, 0.1287474266204837,-0.0173693010018083,
                              -0.0440882539307952, 0.0139810279173995, 0.0087460940474061,
                              -0.0048703529934518,-0.0003917403733770, 0.0006754494064506,
                              -0.0001174767841248])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 16
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d18':
            self.Name ='D18'
            self.g = np.array(\
                              [0.0380779473638791, 0.2438346746125939, 0.6048231236901156,
                               0.6572880780512955, 0.1331973858249927,-0.2932737832791761,
                              -0.0968407832229524, 0.1485407493381306, 0.0307256814793395,
                              -0.0676328290613302, 0.0002509471148340, 0.0223616621236805,
                              -0.0047232047577520,-0.0042815036824636, 0.0018476468830564,
                               0.0002303857635232,-0.0002519631889427, 0.0000393473203163])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 18
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='d20':
            self.Name ='D20'
            self.g = np.array(\
                              [0.0266700579005546, 0.1881768000776863, 0.5272011889317202,
                               0.6884590394536250, 0.2811723436606485,-0.2498464243272283,
                              -0.1959462743773399, 0.1273693403357890, 0.0930573646035802,
                              -0.0713941471663697,-0.0294575368218480, 0.0332126740593703,
                               0.0036065535669880,-0.0107331754833036, 0.0013953517470692,
                               0.0019924052951930,-0.0006858566949566,-0.0001164668551285,
                               0.0000935886703202,-0.0000132642028945])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 20
            self.WTFClass = 'ExtremalPhase'
            self.Transform = 'DWT'
        elif wtfilter.lower()=='c6':
            # **********************************
            # ***  Coiflet filters           ***
            # **********************************
            self.Name ='C6'
            self.g = np.array(\
                              [-0.0156557285289848, -0.0727326213410511, 0.3848648565381134,\
                               0.8525720416423900,  0.3378976709511590,-0.0727322757411889])
            self.h = wmtsa().wmtsa_qmf(self.g)
            self.L = 6
            self.WTFClass = 'Coiflet'
            self.Transform = 'DWT'
        else:
            raise ValueError ('Unrecognised wavelet filter name')

        if transform.lower()=='modwt':
            self.Transform = 'MODWT'
            self.g = self.g / (2**0.5)
            self.h = self.h / (2**0.5)

        elif transform.lower()=='modwpt':
            self.Transform = 'MODWPT'
            self.g = self.g / (2**0.5)
            self.h = self.h / (2**0.5)

class wmtsa():
    def __init__(self) -> None:
        pass
                    
    def wmtsa_qmf(self,a, inverse=False):
        """
        wmtsa_qmf -- Calculate quadrature mirror filter (QMF).
        
        NAME
        wmtsa_qmf -- Calculate quadrature mirror filter (QMF).
        
        INPUTS
        * a           -- filter coefficients (vector).
        * inverse     -- (optional) flag for calculating inverse QMF (Boolean).
                            Default: inverse = False
        
        OUTPUTS
            b            - QMF coefficients (vector).
        
        DESCRIPTION
            wmtsa_qmf calculates the quadrature mirror filter (QMF) of
            for the specified filter coefficients.  If a is a vector,
            the QMF of the vector is calculated. If a is an array, an
            error is raised
        
        The inverse flag, if set, calculates the inverse QMF.  inverse
        is a Boolean values specified as (1/0, y/n, T/F or true/false).
        
        EXAMPLE
            # h is the QMF of g.
            g = [0.7071067811865475 0.7071067811865475];
            h = wmtsa_qmf(g);
        
            # g is the inverse QMF of h.
            h = [0.7071067811865475 -0.7071067811865475];
            g = wmtsa_qmf(h, 1);
        
        ALGORITHM
            g_l = (-1)^(l+1) * h_L-1-l
            h_l = (-1)^l * g_L-1-l
            See pages 75 of WMTSA for additional details.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
        Time Series Analysis. Cambridge: Cambridge University Press.
        
        SEE ALSO
        yn
        """

        a = np.array(a)
        
        # we must deep copy a, otherwise we will modify a too
        b = a.copy()
        
        if len(b.shape)>1:
            raise ValueError('Input array must be 1-dimensional')
        
        b = b[::-1]

        if inverse:
            first = 0
        else:
            first = 1
        
        b[first::2] = -b[first::2]
    
        return b

    def acvs(self, X, estimator='biased', subtract_mean=True, method='fft', dim=-1):
        """
        wmtsa_acvs -- Calculate the autocovariance sequence (ACVS) of a data series.

        INPUTS
        X           -- time series (array).
        estimator   -- (optional) type of estimator
                            Valid values:  'biased', 'unbiased', 'none'
                            Default: 'biased'
        subtract_mean -- (optional) flag whether to subtract mean
                            Default: True = subtract mean
        method      -- (optional) method used to calculate ACVS (character string).
        dim         -- (optional) dimension to compute ACVS along (integer).
                            Default: last dimension
        OUTPUTS
        ACVS        -- autocovariance sequence (ACVS) (vector or matrix).
        
        DESCRIPTION
        wmtsa_acvs calculates the autocovariance sequence (ACVS) for a real valued
        series.
        
        By default, the function calculates the ACVS over the last dimension.
        For the current implementation X must be a 1 or 2d array.
        If X is a vector, ACVS is returned with dimensions as X.  If X is a 2d array,
        ACVS is calculated for the rows.
        If input argument 'dim' is supplied, the ACVS is calculated over that dim.
        
        The estimator option normalizes the ACVS estimate as follows:
        * 'biased'   -- divide by N
        * 'unbiased' -- divide by N - tau
        * 'none'     -- unnormalized.
        
        The 'subtract_mean' input argument specifies whether to subtract
        the mean from the prior to calculating the ACVS. The default is to
        subtract them mean.
        
        The 'method' input argument specifies the method used to calculate
        the ACVS:
            'lag'     -- Calculate taking lag products.
            'fft'     -- Calculate via FFT.
        The default is 'fft'.
        
        
        ALGORITHM
        See page 266 of WMTSA for definition of ACVS.
        See page 269 of WMTSA for definition of biased ACVS estimator.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        """
        
        valid_estimators = ('biased', 'unbiased', 'none')
        
        # check input
        if estimator.lower() not in valid_estimators:
            raise ValueError('Bad estimator: "{}". Valid estimator methods are only: {}'.format(estimator,valid_estimators))    
        try:
            sz   = X.shape
            ndim = len(sz)
            if ndim>2:
                raise TypeError('Can handle onle 1 or 2d arrays')
            else:
                N    = sz[dim]
                ACVS = np.zeros(sz)
        except AttributeError:
            # a scalar
            return 0.0

        if subtract_mean:
            X = X - X.mean(axis=dim)

        if method=='lag':
            if ndim==1:
                for tau in range(N):
                    ACVS[tau] = np.sum(X[:N-tau]*X[tau:])
            elif ndim==2:
                if dim==0:
                    for tau in range(N):
                        ACVS[tau,:] = np.sum(X[:N-tau,:]*X[tau:,:], axis=0)
                elif dim in (-1,1):
                    for tau in range(N):
                        ACVS[:,tau] = np.sum(X[:,:N-tau]*X[:,tau:], axis=0)
        elif method=='fft':
            Nft  = np.int(2**(np.ceil(np.log2(N))))
            Xhat = np.fft.fft(X, Nft, axis=dim)
            ACVS = np.real(np.fft.ifft(Xhat*np.conjugate(Xhat), axis=dim))
            ACVS = ACVS[:N]
        else:
            raise ValueError('Unrecognised method for computing autocovariance')

        if estimator==None:
            pass
        elif estimator.lower()=='biased':
            ACVS = ACVS / np.float(N)
        elif estimator.lower()=='unbiased':
            tau = np.arange(N)
            if (dim==0) & (ndim>1):
                ACVS = ACVS / np.float64(N - tau)[:,np.newaxis]
            else:
                ACVS = ACVS / np.float64(N - tau)
        else:
            raise ValueError('Estimator "{}" is not a valid one'.format(estimator))

        # create even ACVS
        if ndim==2:
            if dim==0:
                ACVS = np.vstack((ACVS[::-1,:],ACVS[1:,:]))
            else:
                ACVS = np.hstack((ACVS[:,::-1],ACVS[:,1:]))
        elif ndim==1:
            ACVS = np.hstack((ACVS[::-1],ACVS[1:]))

        return ACVS

class modwt():
    def modwtj(self, Vin, j, h_t, g_t):
        """
        MODWT transform pyramid algorithm
        see pag.178 WMTSA
        """
        N=len(Vin)
        L=len(h_t)
        Wout=np.zeros(N,dtype=np.float64)
        Vout=np.zeros(N,dtype=np.float64)
        #cdef int k, n, t
        #cdef int N = Vin.shape[0]
        #cdef int L = ht.shape[0]
        #cdef np.ndarray[DTYPE_t, ndim=1] Wout = np.ndarray(N, dtype=DTYPE)
        #def np.ndarray[DTYPE_t, ndim=1] Vout = np.ndarray(N, dtype=DTYPE)

        if L!=g_t.shape[0]: raise ValueError('filters ht and gt must have the same length')
        
        for t in range(N):
            k = t
            Wout[t] = h_t[0] * Vin[k]
            Vout[t] = g_t[0] * Vin[k]
            for n in range(1,L):
                k -= 2**(j - 1)
                if (k < 0):
                    k = k%N
                Wout[t] += h_t[n] * Vin[k]
                Vout[t] += g_t[n] * Vin[k]
        return Wout, Vout


    def modwt(self, X, wtf='la8', nlevels='conservative', boundary='reflection', RetainVJ=False):
        """
        function modwt(X, wtf='la8', nlevels='conservative', boundary='reflection', RetainVJ=False)
        modwt -- Compute the (partial) maximal overlap discrete wavelet transform (MODWT).
        
        NAME
        modwt -- Compute the (partial) maximal overlap discrete wavelet transform (MODWT).
        
        INPUTS
        X          -- set of observations 
                        (vector of length NX)
        wtf        -- (optional) wavelet transform filter name
                        (string, case-insensitve or wtf struct).
                        Default:  'la8'
        nlevels    -- (optional) maximum level J0 (integer) 
                        or method of calculating J0 (string).
                        Valid values: integer>0 or a valid method name
                        Default:  'conservative'
        boundary   -- (optional) boundary conditions to use (string)
                        Valid values: 'circular' or 'reflection'
                        Default: 'reflection'
        RetainVJ   -- (optional) boolean flag to retain V at each
                        decomposition level
                        Default: False
        
        OUTPUTS
        WJt        -- MODWT wavelet coefficents (J x NW array) dwtArray
        VJt        -- MODWT scaling coefficients ((none or J) x NW vector) dwtArray
        
        DESCRIPTION
        modwt calculates the wavelet and scaling coefficients using the maximal
        overlap discrete wavelet transform (MODWT).
        
        The optional input arguments have default values:
        * wtf      -- 'la8' filter
        * nlevels  -- 'convservative' --> J0 < log2( N / (L-1) + 1)
        * boundary -- 'reflection'.
        
        The output arguments include an info attribute with metadata.
        info is a dictionary with the following fields:
        * Transform  -- name of transform ('MODWT')
        * WTF        -- name of wavelet transform filter or a wtf_s struct.
        * NX         -- number of observations in original series (= length(X))
        * NW         -- number of wavelet coefficients
        * J0         -- number of levels of partial decompsition.
        * Boundary   -- boundary conditions applied.
        * Aligned    -- Boolean flag indicating whether coefficients are aligned
                        with original series (1 = true) or not (0 = false).
        * RetainVJ   -- Boolean flag indicating whether VJ scaling coefficients
                        at all levels have been retained (1= true) or not (0 = false).
        * BCs        -- ((1 or J0)x 2) array with indices of last element to the left,
                        and first element to the right which are influenced to some 
                        extent by boundary conditions. Given at each decomposition level
        
        EXAMPLE

        WJt, VJt = modwt(x, 'la8', 6, 'reflection')
        
        ALGORITHM
        See pages 177-178 of WMTSA for description of Pyramid Algorithm for
        the MODWT.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
        Time Series Analysis. Cambridge: Cambridge University Press.
        """

        # Get a valid wavelet transform filter coefficients struct.
        wtf_s = wtfilter(wtf)
    
        wtfname =wtf_s.Name
        g_t = wtf_s.g
        h_t = wtf_s.h
        L  = wtf_s.L
        # wavelet = pywt.Wavelet(wtf)
        # h = wavelet.dec_hi
        # g = wavelet.dec_lo
        # h_t = np.array(h) / np.sqrt(2)
        # g_t = np.array(g) / np.sqrt(2)
        # L=len(g_t)

        # Make sure that X is a numpy array
        X = np.array(X)
        if len(X.shape)>1:
            raise ValueError('Input array must be one-dimensional')
        #  N    = length of original series
        N = X.size
            
        #  If nlevels is an integer > 0, set J0 = nlevels.
        #  otherwise, select J0 based on choice method specified.
        if isinstance(nlevels, str):
            J0 = self.choose_nlevels(nlevels, wtfname, N)
        elif isinstance(nlevels, int):
            if nlevels > 0:
                J0 = nlevels
            else:
                raise ValueError('NegativeJ0, nlevels must be an integer greater than 0.')
        else:
            raise ValueError('Invalid NLevels Value')
        
        if (J0 < 0):
            raise ValueError('Negative J0')
        
        if (2**J0 > N):
            print ('Warning (MODWT):Large J0, JO > log2(Number of samples).')

        # Initialize the scale (Vin) for first level by setting it equal to X
        # using specified  boundary conditions
        if boundary=='reflection':
            Xin = np.hstack((X, X[::-1]))
        elif boundary in ('circular', 'periodic'):
            Xin = X
        else:
            raise ValueError('Invalid Boundary Conditions')

        # NW = length of the extended series = number of coefficients
        NW = Xin.size
        
        # Pre-allocate memory.
        WJt = np.ndarray((J0, NW), dtype=np.float64)*np.nan
        if RetainVJ:
            VJt = np.ndarray((J0, NW), dtype=np.float64)*np.nan
        else:
            VJt = np.ndarray((NW), dtype=np.float64)*np.nan

        # Do the MODWT.
        #import pyximport; pyximport.install()
        # from modwtj import modwtj
        
        Vin = Xin; 
        bw = np.ndarray((J0,2))*np.nan
        for j in range(J0):
            Wt_j, Vout = self.modwtj(Vin, j+1, h_t, g_t)
            WJt[j,:]   = Wt_j
            Vin        = Vout
            if RetainVJ:
                VJt[j,:] = Vout
                
            # boundary values pag.198 WMTSA
            L_j     = self.equivalent_filter_width(L, j+1)
            bw[j,0] = min(L_j - 2, NW-1) #max index to the left
            #bw[j,1] = np.nan #Bc are only at the beginning
        if not RetainVJ:
            VJt[:] = Vout
            bv     = bw[-1,:]
        else:
            bv     = bw

        # Update attributes
        att = {'Transform':'MODWT',
            'WTF'      : wtfname,
            'N'        : N,
            'NW'       : NW,
            'J0'       : J0,
            'Boundary' : boundary,
            'Aligned'  : False,
            'RetainVJ' : RetainVJ,
            'Type'     : 'Wavelet',
            'BCs'      : np.int32(bw)
            }
        WJt = dwtArray(WJt, info=att)

        att = {'Transform':'MODWT',
            'WTF'      : wtfname,
            'N'        : N,
            'NW'       : NW,
            'J0'       : J0,
            'Boundary' : boundary,
            'Aligned'  : False,
            'RetainVJ' : RetainVJ,
            'Type'     : 'Scaling',
            'BCs'      : np.int32(bv)
            }
        VJt = dwtArray(VJt, info=att)
        
        return WJt, VJt


# def modwt(x, filters, level):
#     '''
#     filters: 'db1', 'db2', 'haar', ...
#     return: see matlab
#     '''
#     # filter
#     wavelet = pywt.Wavelet(filters)
#     h = wavelet.dec_hi
#     g = wavelet.dec_lo
#     h_t = np.array(h) / np.sqrt(2)
#     g_t = np.array(g) / np.sqrt(2)
#     wavecoeff = []
#     v_j_1 = x
#     for j in range(level):
#         w = circular_convolve_d(h_t, v_j_1, j + 1)
#         v_j_1 = circular_convolve_d(g_t, v_j_1, j + 1)
#         wavecoeff.append(w)
#     wavecoeff.append(v_j_1)
#     return np.vstack(wavecoeff)  

    def cir_shift(self, WJt, VJ0t, subtract_mean_VJ0t=True):
        """
        shift_modwt_coef -- shift the MODWT wavelet and scaling coefficients.
        
        NAME
            shift_modwt_coef -- Shift the MODWT wavelet and scaling coefficients.

        INPUTS
            WJt          =  JxN dwtArray of MODWT wavelet coefficents
                            where N = number of time intervals,
                                J = number of levels
            VJ0t         =  N dwtArray of MODWT scaling coefficients at level J0.

            subtract_mean_VJ0t = (optional) subtract mean value of scaling coefficient 
                            from itself
                            Default: True

        OUTPUTS
            W  = shifted wavelet coefficients with boundary conditions (dwtArray)
            V  = shifted scaling coefficients with boundary conditions (dwtArray)

        DESCRIPTION
        The MODWT coefficients are circularly shifted at each level so as to 
        properly align the coefficients with the original data series.

        REFERENCES
        See figure 183 of WMTSA.

        SEE ALSO
        modwt, modwt_filter, overplot_modwt_cir_shift_coef_bdry,
        multi_yoffset_plot
        """
        
        # check input
        if type(WJt) != dwtArray:
            raise TypeError('Input must be a dwtArray')
        if WJt.info['Type'] != 'Wavelet':
            raise TypeError('First input array does not contain Wavelet coefficients but {} coefficients'.format(WJt.info['Type']))
        if type(VJ0t) != dwtArray:
            raise TypeError('Input must be a dwtArray')
        if VJ0t.info['Type'] != 'Scaling':
            raise TypeError('Second input array does not contain Scaling coefficients but {} coefficients'.format(VJ0t.info['Type']))
        
        wtf_s = wtfilter(WJt.info['WTF'])
        L  = wtf_s.L
        # wtfname = str(wtf)
        # gt = wtf_s.g
        # ht = wtf_s.h
        # L  = wtf_s.L
        # wavelet = pywt.Wavelet(wtf)
        # h = wavelet.dec_hi
        # g = wavelet.dec_lo
        # h_t = np.array(h) / np.sqrt(2)
        # g_t = np.array(g) / np.sqrt(2)
        # L=len(g_t)
        
        # wavelet = pywt.Wavelet(wtf)
        wtfname       = WJt.info['WTF']
        N             = WJt.info['N']
        NW            = WJt.info['NW']
        J0            = WJt.info['J0']
        
        Nm = min(N,NW)

        if WJt.info['Aligned']:
            print ('WARNING (wmtsa.modwt.cir_shift): Wavelet coefficients are already aligned')
            W = WJt
        else:
            if WJt!=dwtArray([]):
                W = np.ndarray(WJt.shape)*np.nan; bw = np.ndarray((J0,2))*np.nan
                for j in range(J0):
                    # shift wavelet coefficients
                    nuHj = self.advance_wavelet_filter(wtfname, j+1)
                    W[j,:] = np.roll(WJt[j,:], nuHj)
                    
                    #Calculate circularly shifted wavelet coefficient boundary indices at jth level
                    L_j   = self.equivalent_filter_width(L, j+1)
            
                    bw[j,0] = L_j - 2 - np.abs(nuHj) #max index to the left
                    bw[j,1] = Nm - abs(nuHj) #min index to the right
                W = W[:,:Nm]
                # Update attributes
                att = dict(WJt.info,
                        **{'Aligned':True,
                            'BCs'    : bw
                            })
                W = dwtArray(W, info=att)
            else: # if an empty array was given, do nothing and return it
                W = WJt

        if VJ0t.info['Aligned']:
            print ('WARNING (wmtsa.modwt.cir_shift): Wavelet coefficients are already aligned')
            V = VJ0t
        else:
            V = np.ndarray(VJ0t.shape)*np.nan; bv = np.ndarray((2,))*np.nan
            # shift scaling coefficients
            if VJ0t!=dwtArray([]):
                nuGj = self.advance_scaling_filter(wtfname, J0)
                if subtract_mean_VJ0t:
                    VJ0t = VJ0t - VJ0t.mean()
                V    = np.roll(VJ0t, nuGj)
        
                bv[0] = L_j - 2 - np.abs(nuGj) #max index to the left
                bv[1] = Nm - np.abs(nuGj) #min index to the right
                # Update attributes
                att = dict(VJ0t.info,
                        **{'Aligned':True,
                            'BCs'    :np.int32(bv)
                            })
                V = dwtArray(V[:Nm], info=att)
            else: # if an empty array was given, do nothing and return it
                V = VJ0t

        return W,V

    def rot_cum_wav_svar(self, WJt, VJ0t, method='cumsc'):
        """
        rot_cum_wav_svar -- Calculate cumulative sample variance of MODWT wavelet coefficients.
        
        NAME
        rot_cum_wav_svar -- Calculate cumulative sample variance of 
                MODWT wavelet coefficients.
        
        INPUTS
        WJt          -  JxN dwtArray of MODWT wavelet coefficents
                        where N = number of time intervals
                                J = number of levels
                        they can be already rotated or not
        VJ0t         -  N dwtArray of MODWT J0 scaling coefficents
                        they can be already rotated or not
        method       - variance estimate returned
                        'cum'   = cumulative variance
                        'cumsc' = cumulative "scaled" (see pag.189)
                        Default: 'power' 
        
        OUTPUTS
        cwsvar       -  cumulative wavelet sample variance (dwtArray).
        
        DESCRIPTION
        'cumsc' methods is equivalent to the one on pag.189 of WMTSA
        
        EXAMPLE
        
        
        ALGORITHM
        
        cwsvar[j,t] = 1/N * sum( WJt^2 subscript(j,u+nuH_j mod N)) 
                            for t = 0,N-1 at jth level
        for j in range(J):
            rcwsvar[j,:] = cswvar[j,:] - t*cwsvarN[j]/(N-1.)
        
        For details, see page 189 of WMTSA.   
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        
        SEE ALSO
        cir_shift, modwt
        """
        
        if method not in ('power','cum','cumsc'):
            raise ValueError('Valid methods are only: "power", "cum" or "cumsc"')
        
        # check input
        if type(WJt) != dwtArray:
            raise TypeError('Input must be a dwtArray')
        if WJt.info['Type'] != 'Wavelet':
            raise TypeError('First input array does not contain Wavelet coefficients but {} coefficients'.format(WJt.info['Type']))
        if type(VJ0t) != dwtArray:
            raise TypeError('Input must be a dwtArray')
        if VJ0t.info['Type'] != 'Scaling':
            raise TypeError('Second input array does not contain Scaling coefficients but {} coefficients'.format(VJ0t.info['Type']))
                
        # rotate if they are not yet aligned
        WJt,VJ0t = self.cir_shift(WJt, VJ0t) # the check for rotation is done in cir_shift

        # get dimensions
        try:
            J, N   = WJt.shape
        except ValueError:
            N = WJt.size
            J=1
        if len(VJ0t.shape)>1:
            raise ValueError('Only J0 level scaling coefficient should be given')

        pWJt = WJt**2; pVJ0t = VJ0t**2
        
        cwsvar = np.cumsum(pWJt, axis=1)/N
        swsvar = np.cumsum(pVJ0t)/N
        cwsvarN = cwsvar[:,-1]
        swsvarN = swsvar[-1]
        
        if method=='cum':
            Watt = dict(WJt.info.items() + {'Type':'WavRotCumVar'}.items())
            Vatt = dict(VJ0t.info.items() + {'Type':'ScalRotCumVar'}.items())
            return dwtArray(cwsvar/cwsvarN[:,np.newaxis], info=Watt),dwtArray(swsvar/swsvarN, info=Vatt)

        # compute rotated cumulative variance
        t = np.arange(N, dtype=np.float64)

        rcwsvar = cwsvar - t*cwsvarN[:,np.newaxis]/(N-1)
        rswsvar = swsvar - t*swsvarN/(N-1)

        Watt = dict(WJt.info.items() + {'Type':'WavRotCumScVar'}.items())
        Vatt = dict(VJ0t.info.items() + {'Type':'ScalRotCumScVar'}.items())
        return dwtArray(rcwsvar, info=Watt),dwtArray(rswsvar, info=Vatt)

    def running_wvar(self, WJt, Ns=3, overlap=False, ci_method='chi2eta3', p=0.05):
        """
        running_wvar -- Calculate running wavelet variance of circularly-shifted MODWT wavelet coefficients.

        INPUTS
        WJt         = JxN dwtArray of circularly shifted (advanced) MODWT 
                        wavelet coefficents
        Ns           = (optional) number of points in running segment 
                        over which to calculate wavelet variance. An odd number
                        makes more sense.
                        Default value: 3
        overlap      = (optional) return overlapping estimates if True.
                        Default: False
        ci_method    = (optional) method for calculating confidence interval
                        valid values:  'gaussian', 'chi2eta1', 'chi2eta3' or 'none'
                        If None is passed, no confidence interval is computed
                        Default value: 'chi2eta3'
        p            = (optional) percentage point for chi2square distribute
                        Default value: 0.05 ==> 95% confidence interval
        
        OUTPUTS
        rwvar        = J x N_rm array containing running wavelet variances, 
                        where N_rm is number of runnning means.
                        N_rm depends on overlap, if overlap is True, then N_rm=N
                        if overlap is False, N_rm=N/Ns (+1 if N%Ns>0)
        CI_rwvar     = J x 2 x N_rm array containing confidence intervals of
                        running wavelet variances with lower bound (column 1) 
                        and upper bound (column 2).
        indices      = Indices of time points in original data series for which
                        rwvar values are calculated.
        
        DESCRIPTION
        Function calculates the running wavelet variance from the translated
        (circularly shifted) MODWT wavelet coefficients.  User may specify
        the range and steps of time points to over which to calculate wavelet
        variances and number of continguous values (span) to calculate each
        variance.  The running variance is computed for a span of values
        center at the particular time point.
        See Eq. 324 WMTSA
        
        EXAMPLE
        WJt,  VJ0t      = modwt(X, 'la8', 9)
        WJt, TVJ0t     = modwt_cir_shift(WJt, VJ0t)
        rwvar, CI_rwvar, indices = running_wvar(WJt)
        
        NOTES
        1.  User must use circularly shift MODWT wavelet coefficients.
            Use modwt_cir_shift prior to calculating running wavelet variances.
        2.  The biased estimation is used

        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        """
        valid_ci_methods = ('gaussian', 'chi2eta1', 'chi2eta3', 'none')
        # check input
        if ci_method.lower() not in valid_ci_methods:
            raise ValueError('Bad C.I. method: "{}". Valid methods for confidence interval are only: {}'.format(ci_method,valid_ci_methods))
            
        if type(WJt) != dwtArray:
            raise TypeError('Input must be a dwtArray')
        if WJt.info['Type'] != 'Wavelet':
            raise TypeError('Input array does not contain Wavelet coefficients but {} coefficients'.format(WJt.info['Type']))
        if not WJt.info['Aligned']:
            raise TypeError('Input coefficients must be aligned')
        
        J,N = WJt.shape

        Ns = np.int(Ns)
        Ns2 = Ns/2
            
        if overlap:
            rwvar = np.zeros((J,N))*np.nan
            for j in range(J):
                # overlapping running average
                rwvar[j,:] = np.convolve(WJt[j,:]**2, np.ones(Ns), mode='same')
            indices    = np.arange(N)
        else:
            Split  = np.arange(0, N, Ns)
            Denom  = np.hstack((np.diff(Split),N-Split[-1]))
            rwvar  = np.add.reduceat((WJt**2), Split, axis=1)/np.float64(Denom)
            indices = Split + Ns2
            indices[-1] = Split[-1] + (N-Split[-1])/2 # to avoid going after last element

        Watt = dict(WJt.info.items() + {'Type':'MODWT WVAR'}.items()) # we need to update the meta data since now it contains wavelt variance ("power")
        rwvar = dwtArray(rwvar, info=Watt)

        if ci_method.lower()=='none':  
            CI_rwvar = None
        else:
            CI_rwvar = np.zeros((J,2,rwvar.shape[1]))*np.nan
            if overlap:
                if Ns2%2==0:
                    rend = Ns2
                    tend = N-Ns2
                else:
                    rend = Ns2+1   # if Ns is odd, we need to take one more variance estimate on the right
                    tend = N-Ns2-1 # but one less point before finishing the time series
                for t in range(Ns2,tend):
                    CI_rwvar[:,:,t],_ = self.wvar_ci(rwvar[:,t], np.ones(J)*Ns,\
                                                    lbound=np.zeros(J), ubound=np.ones(J)*Ns,\
                                                    ci_method=ci_method, WJt=WJt, p=p)
            else:
                for t in range(rwvar.shape[1]-1):
                    CI_rwvar[:,:,t],_ = self.wvar_ci(rwvar[:,t], np.ones(J)*Ns,\
                                                    lbound=np.zeros(J), ubound=np.ones(J)*Ns,\
                                                    ci_method=ci_method, WJt=WJt, p=p)
                # the last element can come from a different number of
                # averaging points
                CI_rwvar[:,:,-1],_ = self.wvar_ci(rwvar[:,-1], np.ones(J)*(N-Split[-1]),\
                                                lbound=np.zeros(J), ubound=np.ones(J)*(N-Split[-1]),\
                                                ci_method=ci_method, WJt=WJt, p=p)
            
        Watt = dict(WJt.info.items() + {'Type':'RunWavVar'}.items())
    
        return dwtArray(rwvar, info=Watt), CI_rwvar, indices
    
    def wvar(self, WJt, ci_method='chi2eta3', estimator='biased', p=0.05):
        """
        wvar -- Calculate wavelet variance of MODWT wavelet coefficients.
        
        INPUTS
        WJt          = MODWT wavelet coefficients (JxN dwtArray).
                        where N = number of time intervals
                                J = number of levels
        ci_method    = (optional) method for calculating confidence interval
                        valid values:  'gaussian', 'chi2eta1', 'chi2eta3'
                        default: 'chi2eta3'
        estimator    = (optional) type of estimator
                        valid values:  'biased', 'unbiased', 'weaklybiased'
                        default: 'biased'
        p            = (optional) percentage point for chi2square distribution.
                        default: 0.05 ==> 95% confidence interval

        OUTPUTS
        wvar         = wavelet variance (Jx1 dwtArray).
        CI_wvar      = confidence interval of wavelet variance (Jx2 array).
                        lower bound (column 1) and upper bound (column 2).
        edof         = equivalent degrees of freedom (Jx1 vector).
        MJ           = number of coefficients used calculate the wavelet variance at
                        each level (integer).

        NOTES
        MJ is vector containing the number of coefficients used to calculate the 
        wavelet variance at each level. 
        For the unbiased estimator, MJ = MJ for j=1:J0, where MJ is the number 
        of nonboundary MODWT coefficients at each level.
        For the biased estimator, MJ = N for all levels.
        For the weaklybiased estimator, MJ = MJ(Haar), for j=1:J0, where MJ(Haar) 
        is the number of nonboundary MODWT coefficients for Haar filter at each level.
        
        ALGORITHM
        See section 8.3 of WMTSA on page 306.
        For unbiased estimator of wavelet variance, see equation 306b. 
        For biased estimator of wavelet variance, see equation 306c. 
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        """
        
        valid_estimator_methods = ('unbiased', 'biased', 'weaklybiased')
        
        # check input
        if estimator.lower() not in valid_estimator_methods:
            raise ValueError('Bad estimator: "{}". Valid estimator methods are only: {}'.format(estimator,valid_estimator_methods))    
            
        if type(WJt) != dwtArray:
            raise TypeError('Input must be a dwtArray')
        if WJt.info['Type'] != 'Wavelet':
            raise TypeError('Input array does not contain Wavelet coefficients but {} coefficients'.format(WJt.info['Type']))
        if WJt.info['Aligned'] & (estimator=='unbiased'):
            raise TypeError('The unbiased method required wavelet coefficients not circularly shifted')
        
        wtfname = WJt.info['WTF']
        N  = WJt.info['N']
        J  = WJt.info['J0']
        
        if N>WJt.shape[1]:
            if estimator=='biased':
                N = WJt.shape[1] #in this case we assume to be using the function for computing running mean
            else:
                print ('WARNING modwt.wvar: Computing unbiased wavelet variance with less points than the original time series!')
        
        # Do we need to initialize?
        wvar    = np.zeros(J)*np.nan
        CI_wvar = None; edof = None
        
        wtf_s = wtfilter(wtfname)
        L = wtf_s.L

        # prepare attributes to be updated later
        Watt = dict(WJt.info.items() + {'Type':'MODWT WVAR',
                                        'CI Method':ci_method,
                                        'Estimator':estimator,
                                        'p-level'  : p}.items())
            
        if estimator=='unbiased':
            #Unbiased estimator of wavelet variance (equation 306b)
            #Sum of squares of coefficients from L_j to N
            #For unbiased estimator, do not include wavelets coefficients affected by 
            #circularity assumption.

            LJ = self.equivalent_filter_width(L, np.arange(1,J+1))
            MJ = self.num_nonboundary_coef(wtfname, N, np.arange(1,J+1))
            if np.any(MJ==0):
                jmin = np.where(MJ==0)[0][0] + 1
                print ('WARNING (modwt.wvar): Coefficients of order {} and higher are influenced by boundary conditions on all points'.format(jmin))
        
            for j in range(J):
                # we take only the coefficients up to N-1 (after that, they would be due to reflection)
                # This can only work with non rotated coefficients
                # since it considers BCs to be only at the beginning
                wvar[j] = np.sum(WJt[j,(LJ[j]-1):N]**2) / np.float(MJ[j])

            wvar = dwtArray(wvar, info=Watt)
        
            if ci_method!=None:
                lb = LJ-1
                ub = np.ones(J)*N
                CI_wvar, edof = self.wvar_ci(wvar, MJ=MJ, ci_method=ci_method, WJt=WJt, lbound=lb, ubound=ub, p=p)

        elif estimator=='biased':
            # Biased estimator of wavelet variance (equation 306c)
            # Use all coefficients.
            
            MJ = np.ones(J)*N
            wvar = np.sum(WJt[:,:N]**2, axis=1) / np.float(N)

            wvar = dwtArray(wvar, info=Watt)
        
            if ci_method!=None:
                lb = np.zeros(J)
                ub = np.ones(J)*N
                CI_wvar, edof = self.wvar_ci(wvar, MJ=MJ, ci_method=ci_method, WJt=WJt, lbound=lb, ubound=ub, p=p)
        
        elif estimator in ('weaklybiased',):
            # Weakly Biased estimator
            # Use wavelet coefficients that are 1/2 the filter autocorrelation width
            # away from time series boundary.   Over half of signal contribution comes
            # from coefficients within autocorrelation width.
            # This is less retrictive than unbiased estimator but more so biased one.
            # This is equivalent to using circular shifting wavelet coefficients for
            # time alignment and then not including boundary coefficients for Haar
            # filter, since L_j = w_a_j for Haar.

            #TODO: implement         
            raise ValueError ('WEAKLY BIASED NOT IMPLEMENTED')    
    
        return wvar, CI_wvar, edof, MJ

    def wspec(self, WJt, dt=1, estimator='biased', ci_method='chi2eta3', p=0.05):
        """
            wspec -- Convenience function to obtain the spectral estimate from wavelet variance
        INPUTS
        WJt          = MODWT wavelet coefficients (JxN dwtArray).
                        where N = number of time intervals
                                J = number of levels
        dt           = time step of the time series
                        Default: 1
        estimator,ci_method,p  = optional arguments of wvar (see wvar)

        OUTPUTS
        wspec        = wavelet "spectrum" (Jx1 dwtArray).

        NOTES
        
        ALGORITHM
        Cj = 2**j * wvarj *dt
        Based on Eq. 316 of WMTSA
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        """
        
        J = WJt.info['J0']
        
        wv,CI_wvar, edof, MJ = self.wvar(WJt, estimator=estimator, ci_method=ci_method, p=p)

        wspec   = 2**np.arange(1,J+1) * wv * dt
        try:
            CI_wvar = (2**np.arange(1,J+1))[:,np.newaxis] * CI_wvar * dt
        except TypeError:
            CI_wvar = None
        
        return wspec, CI_wvar, edof, MJ 

    def wvar_ci(self, wvar, MJ, lbound=None, ubound=None, ci_method='chi2eta3', WJt=None, p=0.05, moreOut=False):
        """
            wvar_ci -- Calculate confidence interval of MODWT wavelet variance.
        
        INPUTS
        wvar         = wavelet variance (J dwtArray).
        MJ           = number of coefficients used calculate the wavelet variance at
                        each level (J).
        ci_method    = (optional) method for calculating confidence interval
                        valid values:  'gaussian', 'chi2eta1', 'chi2eta3'
                        default: 'chi2eta3'
        WJt          = MODWT wavelet coefficients (JxN array).
                        where N = number of time intervals
                                J = number of levels
                        required for 'gaussian' and 'chi2eta1' methods.
        lbound       = lower bound of range of WJt for calculating ACVS for each
                        level (J vector).
        ubound       = upper bound of range of WJt for calculating ACVS for each
                        level (J vector).
        p            = (optional) percentage point for chi2square distribution.
                        default: 0.05 ==> 95% confidence interval
        moreOut      = Return also Qeta and AJ
                        default: false
        
        OUTPUTS
        CI_wvar      = confidence interval of wavelet variance  (Jx2 array).
                        lower bound (column 1) and upper bound (column 2).
        edof         = equivalent degrees of freedom (Jx1 vector).
        Qeta         = p x 100% percentage point of chi-square(eta) distribution (Jx2 array).
                        lower bound (column 1) and upper bound (column 2).
        AJ           = integral of squared SDF for WJt (Jx1 vector).
        
        DESCRIPTION
        MJ is vector containing the number of coefficients used to calculate the 
        wavelet variance at each level. 
        For the unbiased estimator, MJ = MJ for j=1:J0, where MJ is the number 
        of nonboundary MODWT coefficients at each level.
        For the biased estimator, MJ = N for all levels.
        For the weaklybiased estimator, MJ = MJ(Haar), for j=1:J0, where MJ(Haar) 
        is the number of nonboundary MODWT coefficients for Haar filter at each level.
        
        EXAMPLE
        
        NOTES
        The output argument edof (equivalent degrees of freedom) is returned for
        the chi2 confidence interval methods.  For the gaussian method, a null
        value is returned for edof.
        
        ALGORITHM
        See section 8.4 of WMTSA on pages 311-315.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        """

        # define a function we will need later
        def ci(wvar, eta, p):
            #eq. 313c

            Qeta1 = chi2.ppf(1.0-p, eta)
            Qeta2 = chi2.ppf(p, eta)
            CI_wvar1 = eta * wvar / Qeta1
            CI_wvar2 = eta * wvar / Qeta2
            return  np.vstack((Qeta1,Qeta2)).T, np.vstack((CI_wvar1,CI_wvar2)).T
            
        valid_ci_methods = ('gaussian', 'chi2eta1', 'chi2eta3')
        
        # check input
        if ci_method.lower() not in valid_ci_methods:
            raise ValueError('Bad C.I. method: "{}". Valid methods for confidence interval are only: {}'.format(ci_method,valid_ci_methods))

        if WJt!=None:        
            if type(WJt) != dwtArray:
                raise TypeError('Input wavelet coefficients must be a dwtArray')
            if WJt.info['Type']!='Wavelet':
                raise TypeError('Input array does not contain Wavelet coefficients but {} coefficients'.format(WJt.info['Type']))
        
        if type(wvar) != dwtArray:
                raise TypeError('Wavelet variance must be a dwtArray')
        if wvar.info['Type']!='MODWT WVAR':
            raise TypeError('Input array does not contain Wavelet Variance but {}'.format(WJt.info['Type']))

        if ci_method in ('gaussian', 'chi2eta1'):
            if (WJt==None) | (lbound==None) | (ubound==None):
                raise Exception('Missing required argument WJt, lbound or ubound using "gaussian" or "chi2eta1" method')
            elif np.any((ubound-lbound)!=MJ):
                raise ValueError('MJ is inconsistent with lower and/or upper bounds passed to wvar_ci for some j')
                
        
        J = wvar.size
        CI_wvar = np.ndarray((J,2))
        edof=None; Qeta=None; AJ=None
        
        # Calculate ACVS and AJ used by gaussian and chi2eta1 ci methods.
        if ci_method in ('gaussian', 'chi2eta1'):
            # For 'gaussian', 'chi2eta1' ci methods, 
            # compute AJ (integral of squared SDF for WJt) 
            # via calculating ACVS of WJt. (see page 312 of WMTSA).
        
            AJ = np.ndarray(J)
            for j in range(J):
                if MJ[j]>0:
                    # from wmtsa import acvs
                    ACVS  = wmtsa.acvs(WJt[j, lbound[j]:ubound[j]], estimator='biased', subtract_mean=False);
                    # Get ACVS for positive lags (there are MJ coefficients in WJt)
                    ACVS  = ACVS[(MJ[j]-1):]
                    AJ[j] = 0.5*ACVS[0]**2 + np.sum(ACVS[1:]**2)
        
        #Calculate confidence intervals
        if ci_method=='gaussian':
            # Gaussian method, Eq. 311 of WMSTA
            VARwvar = 2.0 * AJ / MJ
            phi1 = norm.ppf(1-p)
            CI_wvar[:,0] = wvar - phi1 * VARwvar**0.5
            CI_wvar[:,1] = wvar + phi1 * VARwvar**0.5
        
        if ci_method=='chi2eta1':
            # Chi-squar equivalent degree of freedom method 1
            edof = MJ * (wvar**2) / AJ #this is eta1 of eq. 313d WMTSA
            Qeta, CI_wvar = ci(wvar, edof, p) #this gives c.i. in 313c WMTSA
        
        elif ci_method=='chi2eta2':
            #TODO: implement chi2eta2 method
            #Eq.314b and 313c
            raise ValueError('Not implemented, it needs an assumption of the shape of the spectrum.')
        
        elif ci_method=='chi2eta3':
            # Chi-square wquivalent degree of freedom method 3
            j_range = np.arange(1,J+1)
            edof = np.maximum((MJ/(2.0**j_range)), 1.0) #this is eta3 of eq. 314c WMTSA
            Qeta, CI_wvar = ci(wvar, edof, p)

        if moreOut:    
            return CI_wvar, edof, Qeta, AJ
        else:
            return CI_wvar, edof
  
    def advance_time_series_filter(self, wtfname):
        """
        advance_time_series_filter -- Calculate the advance of the time series or filter for a given wavelet.
        
        NAME
        advance_time_series_filter -- Calculate the advance of the time series or filter for a given wavelet.
        
        SYNOPSIS
        nu = advance_time_series_filter(wtfname)
        
        INPUTS
        wtfname      -  string containing name of WMTSA-supported wavelet filter.
        
        OUTPUTS
        nu           -  advance of time series for specified wavelet filter.
        
        SIDE EFFECTS
        wavelet is a WMTSA-supported wavelet filter; otherwise error.
        
        DESCRIPTION
        
        EXAMPLE
        
        ALGORITHM
        
        For Least Asymmetric filters, equation 112e of WMTSA:
        nu =   -L/2 + 1,   for L/2 is even;
            =   -L/2,       for L = 10 or 18;
            =   -L/2 + 2,   for L = 14.  
        
        For Best Localized filter, page 119 of WMTSA.
        nu =   -5,         for L = 14;
            =   -11,        for L = 18;
            =   -9,         for L = 20.
        
        For Coiflet filters, page 124 and equation 124 of WMTSA:
        nu =   -2*L/3 + 1
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        
        SEE ALSO
        dwt_filter    
        """

        
        def advance_least_asymetric_filter(L):
            #Equation 112c of WMTSA.
            if L in(10, 18):
                nu = -(L/2)
            elif L==14:
                nu = -(L/2) + 2
            elif (L/2)%2 == 0:
                #L/2 is even, i.e. L = 8, 12, 16, 20
                nu = -(L/2) + 1
            else:
                raise ValueError('Invalid filter length (L = {}) specified.'.format(L))
            return nu

        def advance_best_localized_filter(L):
            #Page 119 of WMTSA.
            if L==14:
                nu = -5
            elif L==18:
                nu = -11
            elif L==20:
                nu = -9
            else:
                pass
            return nu
    
        def advance_coiflet_filter(L):
            #Page 124 and equation 124 of WMTSA
            nu = -(2 * L / 3.) + 1
            return nu

        # Get a valid wavelet transform filter coefficients struct.
        wtf_s = wtfilter(wtfname)
        L     = wtf_s.L
        # wtfname = str(wtf)
        # gt = wtf_s.g
        # ht = wtf_s.h
        # L  = wtf_s.L
        # wavelet = pywt.Wavelet(wtf)
        # h = wavelet.dec_hi
        # g = wavelet.dec_lo
        # h_t = np.array(h) / np.sqrt(2)
        # g_t = np.array(g) / np.sqrt(2)
        # L=len(g_t)
        nu = np.nan

        #Haar
        if wtfname.lower() in ('haar','d2'):
            nu = 0
        # Haar filter
        # Value from Figure 115
        elif wtfname.lower() in ('d4'):
            nu = -1
        #Extremal Phase filters
        #case {'haar', 'd4', 'd6', 'd8', 'd12', 'd14', 'd16', 'd18', 'd20'}
        elif wtfname.lower() in ('d6', 'd8', 'd12', 'd14', 'd16', 'd18', 'd20'):
            raise ValueError('Need to determine nu for Extremal Phase filters  -  Is it -1 for all filters?.')
        #Least Asymmetric filters
        elif wtfname.lower() in ('la8', 'la10', 'la12', 'la14', 'la18', 'la16', 'la20'):
            nu = advance_least_asymetric_filter(L)
        #Best Localized filters
        elif wtfname.lower() in ('bl14', 'bl18', 'bl20'):
            nu = advance_best_localized_filter(L)
        #Coiflet filters
        elif wtfname.lower() in ('c6', 'c12', 'c18', 'c24', 'c30'):
            nu = advance_coiflet_filter(L)
        #otherwise
        else:
            pass
        
        return np.int16(np.around(nu))

    def advance_wavelet_filter(self, wtfname, j):
        """
        advance_wavelet_filter -- Calculate the advance of the wavelet filter at jth level for a given wavelet.
        
        NAME
        advance_wavelet_filter -- Calculate the advance of the wavelet filter at jth level for a given wavelet.

        INPUTS
        wtfname      = string containing name of WMTSA-supported wavelet filter.
        j            = jth level (index) of scale or a range of j levels of scales
                        (integer or Jx1 vector of integers).
        
        OUTPUTS
        nuHj         = advance of wavelet filter at jth level
                        (integer or vector of integers).
        
        SIDE EFFECTS
        wavelet is a WMTSA-supported wavelet filter; otherwise error.
        
        ALGORITHM
        nuHj = - (2^(j-1) * (L-1) + nu);
        
        For details, see equation 114b of WMTSA.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        
        SEE ALSO
        advance_time_series_filter, dwt_filter
        """

        # Get a valid wavelet transform filter coefficients struct.
        wtf_s = wtfilter(wtfname)
        L     = wtf_s.L
        # wtfname = str(wtf)
        # gt = wtf_s.g
        # ht = wtf_s.h
        # L  = wtf_s.L
        # wavelet = pywt.Wavelet(wtf)
        # h = wavelet.dec_hi
        # g = wavelet.dec_lo
        # h_t = np.array(h) / np.sqrt(2)
        # g_t = np.array(g) / np.sqrt(2)
        # L=len(g_t)
        nu = self.advance_time_series_filter(wtfname)

        nuHj = -(2**(j-1) * (L-1) + nu)

        return nuHj

    def advance_scaling_filter(self, wtfname, j):
        """
        advance_scaling_filter -- Calculate the value to advance scaling filter at jth level for a given wavelet.
        
        NAME
        advance_scaling_filter -- Calculate the value to advance scaling filter at jth level for a given wavelet.
        
        SYNOPSIS
        nuGj = advance_scaling_filter(wtfname, level)
        
        INPUTS
        wtfname      = string containing name of WMTSA-supported wavelet filter.
        j            = jth level (index) of scale or a range of j levels of scales
                        (integer or vector of integers).
        
        OUTPUTS
        nuGj         = advance of scaling filter at specified levels.
        
        SIDE EFFECTS
        wavelet is a WMTSA-supported scaling filter; otherwise error.
        
        ALGORITHM
        nuGj = (2^j - 1) * nu
        
        For details, see equation 114a of WMTSA.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        
        SEE ALSO
        advance_time_series_filter, dwt_filter
        """

        if wtfname.lower()=='haar':
            nuGj = self.advance_wavelet_filter('haar', j)
        else:
            nu = self.advance_time_series_filter(wtfname)
            nuGj = (2**j - 1) * nu

        return nuGj

    def equivalent_filter_width(self, L, j):
        """
        equivalent_filter_width -- Calculate width of the equivalent wavelet or scaling filter.
        
        NAME
        equivalent_filter_width -- Calculate width of the equivalent wavelet or scaling filter.
        
        INPUTS
        * L          --  width of wavelet or scaling filter (unit scale).
        * j          --  jth level (index) of scale or a range of j levels of scales. 
                            (integer or vector of integers).
        
        OUTPUTS
        * Lj         -- equivalent width of wavelet or scaling filter for specified
                        levels (integer or J vector of integers).
        
        SIDEEFFECTS
        1.  L > 0, otherwise error.
        2.  j > 0, otherwise error.
        
        DESCRIPTION
        Given the length of a wavelet or scaling filter, the function calculates the
        width of the equivalent filter a level or range of levels j for the specified
        base filter width L.
        
        ALGORITHM
            Lj = (2^j - 1) * (L - 1) + 1  (equation 96a of WMTSA)
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        """
        #Check input arguments and set defaults.
        if L<1:
            raise ValueError('L must be positive')
        if np.any(j<1):
            raise ValueError('j must be positive')

        Lj = (2.0**j - 1) * (L - 1) + 1

        return Lj



    def choose_nlevels(self, choice, wtfname, N):
        """
        choose_nlevels -- Select J0 based on choice, wavelet filter and data series length.
        
        NAME
        choose_nlevels -- Select J0 based on choice, wavelet filter and data series length.
        
        USAGE
        J0 = choose_nlevels(choice, wtfname, N)
        
        INPUTS
        choice      -- choice for method for calculating J0 (string)
                    Valid Values:
                    'conservative'
                    'max', 'maximum'
                    'supermax', 'supermaximum'
        wtfname     -- wavelet transform filter name (string)
                    Valid Values:  see modwt_filter
        N           -- number of observations.
        
        OUTPUT
        J0          -- number of levels (J0) based selection criteria.
        
        SIDE EFFECTS
        1.  wtfname is a WMTSA-supported MODWT wtfname, otherwise error.
        2.  N > 0, otherwise error.
        
        DESCRIPTION
        
        
        EXAMPLE
        J0 = choose_nlevels('convservative', 'la8', N)
        
        ERRORS  
        WMTSA:MODWT:InvalidNumLevels    =  Invalid type/value specified for nlevels.
        
        ALGORITHM
        for 'conservative':              J0  < log2( N / (L-1) + 1)
        for 'max', 'maximum':            J0 =< log2(N)
        for 'supermax', 'supermaximum':  J0 =< log2(1.5 * N)
        
        For further details, see page 200 of WMTSA.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
        Time Series Analysis. Cambridge: Cambridge University Press.
        
        SEE ALSO
        modwt_filter
        """
        
        available_choices = ('conservative', 'max', 'supermax')

        #Check for valid wtfname and get wavelet filter coefficients

        wtf = wtfilter(wtfname)

        L = wtf.L

        if choice=='conservative':
            J0 = np.floor(np.log2( (np.float(N) / (L - 1)) - 1))
        elif choice in ('max', 'maximum'):
            J0 = np.floor(np.log2(N))
        elif ('supermax', 'supermaximum'):
            J0 = np.floor(np.log2(1.5 * N))
        else:
            raise ValueError('WMTSA:invalidNLevelsValue: available choices are {}'.format(available_choices))
        return np.int(J0)

    def num_nonboundary_coef(self, wtfname, N, j):
        """
        modwt_num_nonboundary_coef -- Calculate number of nonboundary MODWT coefficients for jth level.
        
        INPUTS
        * wtfname    -- name of wavelet transform filter (string).
        * N          -- number of samples (integer).
        * j          -- jth level (index) of scale or range of j levels.
                        (integer or vector of integers).
        
        OUTPUTS
        * MJ         -- number of nonboundary MODWT coefficients for specified
                        levels (integer or Jx1 vector of integers).
        
        DESCRIPTION
        N-Lj+1 can become negative for large j, so set MJ = min(MJ, 0).
        
        EXAMPLE
        
        ALGORITHM
        M_j = N - Lj + 1
        
        see page 306 of WMTSA for definition.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University _roPress.
        """
        # Check for valid wtf and get wtf filter coefficients
        wtf = wtfilter(wtfname)
        
        L = wtf.L
        
        N = np.int(N); j = np.int32(j)
        
        # Calculate MJ
        Lj = self.equivalent_filter_width(L, j)
        MJ = N - Lj + 1
        MJ = np.maximum(MJ, 0)
        
        return MJ

class modwpt():
    # from wmtsa_cima import dwtArray, wtfilter
    # from wmtsa.modwt import choose_nlevels, equivalent_filter_width

    def modwptjn(self, Win,j0, ht, gt):
        """
        MODWPT transform pyramid algorithm
        see pag.231 WMTSA
        """
        N=Win.shape[1]
        L=len(ht)
        Wout=np.zeros(N,dtype=np.float64)
        # cdef int j, k, n, t, l
        # cdef int N = Win.shape[1]
        # cdef int L = ht.shape[0]
        # cdef np.ndarray[DTYPE_t, ndim=2] Wout
        
        if L!=gt.shape[0]: raise ValueError('filters ht and gt must have the same length')

        for j in range(1,j0+1):
            Wout = np.ndarray((2**j,N), dtype=np.float64)
            for n in range(0,2**j,4):
                for t in range(N):
                    k = t
                    Wout[n,t] = gt[0] * Win[n//2,k]
                    for l in range(1,L):
                        k -= 2**(j - 1)
                        if (k < 0):
                            k += N
                        Wout[n,t] += gt[l] * Win[n//2,k]
            for n in range(3,2**j,4):
                for t in range(N):
                    k = t
                    Wout[n,t] = gt[0] * Win[n//2,k]
                    for l in range(1,L):
                        k -= 2**(j - 1)
                        if (k < 0):
                            k += N
                        Wout[n,t] += gt[l] * Win[n//2,k]
            for n in range(1,2**j,4):
                for t in range(N):
                    k = t
                    Wout[n,t] = ht[0] * Win[n//2,k]
                    for l in range(1,L):
                        k -= 2**(j - 1)
                        if (k < 0):
                            k += N
                        Wout[n,t] += ht[l] * Win[n//2,k]
            for n in range(2,2**j,4):
                for t in range(N):
                    k = t
                    Wout[n,t] = ht[0] * Win[n//2,k]
                    for l in range(1,L):
                        k -= 2**(j - 1)
                        if (k < 0):
                            k += N
                        Wout[n,t] += ht[l] * Win[n//2,k]
            Win = Wout
        return Wout

    def modwpt(self, X, wtf='la8', nlevels='conservative', boundary='reflection'):
        """
        function modwpt(X, wtf='la8', nlevels='conservative', boundary='reflection')
        modwt -- Compute the (partial) maximal overlap discrete wavelet packet transform (MODWPT).
        
        NAME
        modwpt -- Compute the (partial) maximal overlap discrete wavelet packet transform (MODWPT).
        
        INPUTS
        X          -- set of observations 
                        (vector of length NX)
        wtf        -- (optional) wavelet transform filter name
                        (string, case-insensitve or wtf struct).
                        Default:  'la8'
        nlevels    -- (optional) maximum level J0 (integer) 
                        or method of calculating J0 (string).
                        Valid values: integer>0 or a valid method name
                        Default:  'conservative'
        boundary   -- (optional) boundary conditions to use (string)
                        Valid values: 'circular' or 'reflection'
                        Default: 'reflection'
        
        OUTPUTS
        WJnt       -- MODWPT wavelet coefficents (2**J0 x NW array) dwtArray
        
        DESCRIPTION
        modwpt calculates the wavelet packet coefficients using the MODWPT.
        
        The output arguments include an info attribute with metadata.
        info is a dictionary with the following fields:
        * Transform  -- name of transform ('MODWPT')
        * WTF        -- name of wavelet transform filter or a wtf_s struct.
        * NX         -- number of observations in original series (= length(X))
        * NW         -- number of wavelet coefficients
        * J0         -- number of levels of partial decompsition.
        * Boundary   -- boundary conditions applied.
        * Aligned    -- Boolean flag indicating whether coefficients are aligned
                        with original series (1 = true) or not (0 = false).
        * BCs        -- (n x 2) array with indices of last element to the left,
                        and first element to the right which are influenced to some 
                        extent by boundary conditions. Given at each decomposition level

        
        EXAMPLE

        WJnt = modwpt(x, 'la8', 6, 'reflection')
        
        NOTES
        
        ALGORITHM
        See pag. 231 of WMTSA for description of Pyramid Algorithm for
        the MODWPT.
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
        Time Series Analysis. Cambridge: Cambridge University Press.
        """

        # Get a valid wavelet transform filter coefficients struct.
        wtf_s = wtfilter(wtf, transform = 'MODWPT')
    
        wtfname = wtf_s.Name
        gt = wtf_s.g
        ht = wtf_s.h

        # Make sure that X is a numpy array
        X = np.array(X)
        if len(X.shape)>1:
            raise ValueError('Input array must be one-dimensional')
        #  N    = length of original series
        N = X.size
            
        #  If nlevels is an integer > 0, set J0 = nlevels.
        #  otherwise, select J0 based on choice method specified.
        if isinstance(nlevels, str):
            J0 =modwt.choose_nlevels(nlevels, wtfname, N)
        elif isinstance(nlevels, int):
            if nlevels > 0:
                J0 = nlevels
            else:
                raise ValueError('Negative J0, nlevels must be an integer greater than 0.')
        else:
            raise ValueError('Invalid NLevels Value')
        
        if (J0 < 0):
            raise ValueError('Negative J0')
        
        if (2**J0 > N):
            print ('Warning (MODWT) Large J0, > log2(Number of samples).')

        # Initialize the scale (Vin) for first level by setting it equal to X
        # using specified  boundary conditions
        if boundary=='reflection':
            Xin = np.hstack((X, X[::-1]))
        elif boundary in ('circular', 'periodic'):
            Xin = X
        else:
            raise ValueError('Invalid Boundary Conditions')

        # NW = length of the extended series = number of coefficients
        NW = Xin.size
        
        # Do the MODWPT.
        #import pyximport; pyximport.install()
        # from modwptjn import modwptjn
        # We have to add a dimension to Win in order to
        # use modptjn
        Win = np.ndarray((1,NW)); Win[0,:] = Xin
        bw = np.ndarray((2**J0,2))*np.nan
        Wout = self.modwptjn(Win, J0, ht, gt)

        # Update attributes
        att = {'Transform':'MODWPT',
            'WTF'      : wtfname,
            'N'        : N,
            'NW'       : NW,
            'J0'       : J0,
            'Boundary' : boundary,
            'Aligned'  : False,
            'Type'     : 'Wavelet',
            'BCs'      : np.int32(bw)
            }
        WJnt = dwtArray(Wout, info=att)
        
        return WJnt

    def modwpt_cir_shift(self,WJt):
        """
        shift_modwt_coef -- shift the MODWT wavelet and scaling coefficients.
        
        NAME
            shift_modwt_coef -- Shift the MODWT wavelet and scaling coefficients.

        INPUTS
            WJt          =  (2**J)xN dwtArray of MODWPT wavelet coefficents
                            where N = number of time intervals,
                                J = number of levels

        OUTPUTS
            W  = shifted wavelet coefficients with boundary conditions (dwtArray)

        DESCRIPTION
        The MODWPT coefficients are circularly shifted at each level so as to 
        properly align the coefficients with the original data series.

        REFERENCES
        See pag.230 of WMTSA.
        """
        
        # check input
        if type(WJt) != dwtArray:
            raise TypeError('Input must be a dwtArray')
        if WJt.info['Type'] != 'Wavelet':
            raise TypeError('Input array does not contain Wavelet coefficients but {} coefficients'.format(WJt.info['Type']))
        if WJt.info['Transform'] != 'MODWPT':
            raise TypeError('Input array does not contain MODWPT coefficients but {} coefficients'.format(WJt.info['Transform']))
        
        wtf_s = wtfilter(WJt.info['WTF'])
        L  = wtf_s.L

        wtfname       = WJt.info['WTF']
        N             = WJt.info['N']
        NW            = WJt.info['NW']
        J0            = WJt.info['J0']
        
        Nm = min(N,NW)

        if WJt.info['Aligned']:
            print ('WARNING (wmtsa.modwpt.modwpt_cir_shift): Coefficients are already aligned')
            W = WJt
        else:
            if WJt!=dwtArray([]):
                W = np.ndarray(WJt.shape)*np.nan; bw = np.ndarray((2**J0,2))*np.nan
                for n in range(2**J0):
                    # shift wavelet coefficients
                    nujn = advance_filter(wtfname, J0)
                    W[n,:] = np.roll(WJt[n,:], nujn)
                    
                    #Calculate circularly shifted wavelet coefficient boundary indices at jth level
                    L_j   = modwt.equivalent_filter_width(L, J0)
            
                    bw[n,0] = L_j - 2 - np.abs(nujn) #max index to the left
                    bw[n,1] = Nm - abs(nujn) #min index to the right
                W = W[:,:Nm]
                # Update attributes
                att = dict(WJt.info, 
                        **{'Aligned':True,
                            'BCs'    :np.int32(bw)
                            })
                W = dwtArray(W, info=att)
            else: # if an empty array was given, do nothing and return it
                W = WJt
        return W

    def advance_filter(self, wtfname, j):
        """
        advance_time_series_filter -- Calculate the advance of the time series or filter for a given wavelet.
        
        NAME
        advance_time_series_filter -- Calculate the advance of the time series or filter for a given wavelet.
        
        SYNOPSIS
        nujn = advance_time_series_filter(wtfname,j)
        
        INPUTS
        wtfname      -  string containing name of WMTSA-supported wavelet filter.
        
        OUTPUTS
        nu           -  advance of time series for specified wavelet filter.
        
        SIDE EFFECTS
        wavelet is a WMTSA-supported wavelet filter; otherwise error.
        
        DESCRIPTION
        
        EXAMPLE
        
        ALGORITHM
        
        REFERENCES
        Percival, D. B. and A. T. Walden (2000) Wavelet Methods for
            Time Series Analysis. Cambridge: Cambridge University Press.
        
        SEE ALSO
        dwt_filter    
        """

        def Sjn1(J0):
            """
            See pag. 229 and pag. 215 WMTSA
            """
            cjIn = np.array([0,1]) #cj1,n
            for j in range(2,J0):
                for n in range(2**j):
                    mod = n%4
                    if (mod==0)|(mod==3):
                        cjOut = np.hstack((cjIn,0))
                    else:
                        cjOut = np.hstack((cjIn,1))
                cjIn = cjOut
            Sjn1 = np.sum(cjOut*(2**np.arange(J0)))
            return Sjn1
            
        
        def advance_least_asymetric_filter(L, L_j, j):
            #Equation 230 of WMTSA
            if L in(10, 18):
                nu = -(L_j//2.) - (2**(j-1) - Sjn1(j)) +1
            elif L==14:
                nu = -(L_j//2.) + 3*(2**(j-1) - Sjn1(j)) -1
            elif (L//2)%2 == 0:
                #L//2 is even, i.e. L = 8, 12, 16, 20
                nu = -(L_j//2.) + (2**(j-1) - Sjn1(j))
            else:
                raise ValueError('Invalid filter length (L = {}) specified.'.format(L))
            return nu

        def advance_coiflet_filter(L, L_j, j):
            #Page 124 and equation 124 of WMTSA
            nu = -(L_j//2.) - (L_j-3)/3.0*(2**(j-1) - Sjn1(j) - 0.5) + 0.5
            return nu

        # Get a valid wavelet transform filter coefficients struct.
        wtf_s = wtfilter(wtfname)
        L     = wtf_s.L
        L_j   = modwt.equivalent_filter_width(L, j)

        nujn = np.nan

        #Haar
        if wtfname.lower() in ('haar','d2'):
            nujn = 0
        #Least Asymmetric filters
        elif wtfname.lower() in ('la8', 'la10', 'la12', 'la14', 'la18', 'la16', 'la20'):
            nujn = advance_least_asymetric_filter(L, L_j, j)
        #Coiflet filters
        elif wtfname.lower() in ('c6', 'c12', 'c18', 'c24', 'c30'):
            nujn = advance_coiflet_filter(L, L_j, j)
        #otherwise
        else:
            pass
        
        return np.int16(np.around(nujn))